/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectdataa;

import java.io.*;
import java.util.LinkedList;
import java.util.Scanner;
import static projectdataa.Cipher.decode;
import static projectdataa.Cipher.encryptionMethod;
import static projectdataa.SinglyLinkedList.reverse;

public class Projectdataa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       SinglyLinkedList sList = new SinglyLinkedList();  
        Scanner input = new Scanner(System.in);
        Scanner in = new Scanner(System.in);
        
     
              int choice = 0;
while(choice != 4) {
System.out.println("MENU : ");
System.out.println("1. Cipher ");
System.out.println("2. Merge ");
System.out.println("3. Singly LinkedList:  ");
System.out.println("4. Exit");
System.out.print("Enter choice: ");
choice = sc.nextInt();
System.out.println();
switch(choice) {
     
    case 1:
int choicee = 0;
while(choicee != 3) {
System.out.println("MENU Cipher : ");
System.out.println("1. Encryption: ");
System.out.println("2. Decryption ");
System.out.println("3. Exit");
System.out.println("Enter choice: ");
choicee = sc.nextInt();
System.out.println();
switch (choicee) {
    case 1:
        System.out.println("Enter the text to encrypt: ");
        String tex = input.nextLine();
        System.out.println("Enter the key: ");
        int key = input.nextInt();
        input.nextLine();
        System.out.println("Encrypted text is : "+encryptionMethod(tex, key));
        System.out.println();
       

        break;
        
   
    
    case 2: 
         System.out.println("Please enter text to decryption: ");
         String code = input.nextLine();
         System.out.println("Please enter Shift  Number:");
         int number1 = input.nextInt();
         input.nextLine();
         System.out.println("Result:");
         System.out.println(decode(code, number1));
                  
                    break;
       
    case 3:
System.out.println("Exiting....");
break;
}
}   
   break;
        
       
 case 2:
  
                    Merge list1 = new Merge();
                    Merge list2 = new Merge();
                    System.out.println("Enter first list :");
                    String[] string1 = input.nextLine().split(" ");

                    System.out.println("Enter second list :");
                    String[] string2 = input.nextLine().split(" ");
                    for (int i = 0; i < string1.length; i++) {
                        list1.insert(string1[i]);
                    }
                    for (int i = 0; i < string2.length; i++) {
                        list2.insert(string2[i]);
                    }
                    Merge merged = list1.merge(list1, list2);

                    System.out.println("Result ");
                    merged.Display();
                    System.out.println();
                    break;

    
     
     
    
        case 3: 
                Scanner q = new Scanner (System.in);

         System.out.println("Enter A sentance : ");
         String str = q.nextLine();
         sList.add(str);
        System.out.println(" Added ");
        System.out.println("Reverse: ");
        System.out.print(" After: ");
        sList.reverse(str);
        System.out.println();

                    break;

 case 4:
    System.out.println("Exiting....");
break;
}
        
    }
    }
    

	
}

