
package projectdataa;

import java.util.*;
     
  

import java.util.*;


public class SinglyLinkedList{
    public Node head = null;
    public Node tail = null;

    public void add(String data){
        Node newNode = new Node(data);
        if(head == null){
            head = newNode;
            tail = newNode;
        }
        else{
            tail.next = newNode;
            tail = newNode;
        }
    }
    
    class Node{  
     public String data;  
        Node next;  
  
        public Node(String data) {  
            this.data = data;  
            this.next = null;  
        }  

    }

    static void reverse(String str){
        // base case
        if(str.length() == 0){
            return;
        }
        // recursive case
        else{
            int index = str.indexOf(" "); // find the index of the first space
            if(index == -1){    // if there is no space, print the string and return
                System.out.print(str);  // print the string
                return; // return
            }
            else{   // if there is a space, print the string after the space and call the function again
                reverse(str.substring(index + 1));  // call the function again
                System.out.print(" " + str.substring(0, index));    // print the string before the space
            }
        }
    }
}
