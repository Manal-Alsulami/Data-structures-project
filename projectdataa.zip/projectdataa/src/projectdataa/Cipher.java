/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectdataa;

import java.util.Scanner;

public class Cipher {
   
    
    /*
    PSEUDOCODE:
    BEGIN
function encryptionMethod(tex, key):
    ctext = ""
    loop from i = 0 to lengthOf(tex) - 1
        if tex.charAt(i) is uppercase then:
            c = (tex.charAt(i) + key - 65) % 26 + 65
            ctext = ctext + c
        else if tex.charAt(i) is lowercase then:
            c = (tex.charAt(i) + key - 97) % 26 + 97
            ctext = ctext + c
        else:
            ctext = ctext + tex.charAt(i)
        end if
    end loop
    return ctext
END function
    */
    


    
    public static String encryptionMethod(String tex, int key) {
        String ctext = "";

        for (int i = 0; i < tex.length(); i++) {
            if (Character.isUpperCase(tex.charAt(i)))
                ctext += (char) (((int) tex.charAt(i) + key - 65) % 26 + 65);
            else if (Character.isLowerCase(tex.charAt(i)))
                ctext += (char) (((int) tex.charAt(i) + key - 97) % 26 + 97);
            else
                ctext += tex.charAt(i);
        }

        return ctext;
    } 
 
 
    
  
    /** START 
        String originalText = "";

        for (int i = 0; i < cipherText.length(); i++) 
            if (cipherText.charAt(i) == ' ') THEN
                originalText = originalText + ' ';
             Else if (cipherText.charAt(i) - number < 97) 
                originalText = originalText + (char) (cipherText.charAt(i) - number + 26)
             Else 
                originalText = originalText + (char) ((cipherText.charAt(i) - number)
            End For
        
        Return originalText

       END */
    public static String decode(String cipherText, int key) {
        String originalText = "";
        for (int i = 0; i < cipherText.length(); i++) {
            if (cipherText.charAt(i) == ' ') {
                originalText = originalText + ' ';
            } else if (cipherText.charAt(i) - key < 97) {
                originalText = originalText + (char) (cipherText.charAt(i) - key + 26);
            } else {
                originalText = originalText + (char) ((cipherText.charAt(i) - key));
            }
        }
        return originalText;
    }
}
